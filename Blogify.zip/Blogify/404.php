<?php 
    get_header();
    ?>

    <br>
    <br>
    <br>

    <div class="row s-footer__subscribe">
                <div class="column lg-12">

                    <h2>Seems you are lost.</h2>
                    <p>Let's take you back to to home page</p>

                </div>
            </div>
<?php 
    get_footer();
    ?>